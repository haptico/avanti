<?php echo CHtml::link('Restore database', array('site/restore'), array(
	'confirm'=>'Are you sure you want to restore the database?',
)); ?>
