<div class="span2">
	<ul class="messages-nav pills">
		<li><a href="<?php echo $this->createUrl('inbox/') ?>">inbox</a></li>
		<li><a href="<?php echo $this->createUrl('sent/sent') ?>">sent</a></li>
		<li><a href="<?php echo $this->createUrl('compose/') ?>">compose</a></li>
	</ul>
</div>
